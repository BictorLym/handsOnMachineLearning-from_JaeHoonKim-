package com.example.lym_20131034

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
