import 'dart:math';

void main(){
  List<int>numbers = [100, 200, 300, 400, 250, 500, 300];
  print(max(numbers[5], numbers[0]));
  print(sqrt(numbers[4]));
  print(average(numbers));

}
double average(List<int> numbers){
  double avg = 0;
  for(int i = 0; i < numbers.length; i++){
    avg += numbers[i];
  }
  avg = avg / numbers.length;
  return avg;
}