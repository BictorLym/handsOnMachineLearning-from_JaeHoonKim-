void main(){
  Account account1("117-123-1", 10000);
  Account account2("")
}
class Account{
  String name;

  int money;

  Account(this.name, this.money);
}