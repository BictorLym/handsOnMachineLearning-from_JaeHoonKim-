import 'dart:ffi';
import 'dart:io';

void main(){
  Map<String, int>basket = {"apple": 50,
                            "banana": 10,
                            "grape":5
  };
  print("apple: ${basket["apple"]}");
  print("banana: ${basket["banana"]}");
  print("grape: ${basket["grape"]}");
  String contents = basket.toString();
  print(contents);
  File myFile = File('basket.txt');
  // myFile.openWrite()
  myFile.writeAsString(contents);

}