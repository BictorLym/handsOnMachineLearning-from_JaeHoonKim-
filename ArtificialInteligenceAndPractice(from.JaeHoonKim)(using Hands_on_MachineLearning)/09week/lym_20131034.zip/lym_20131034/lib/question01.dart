void main(){
  Set<double> a = {0.15, 0.25, 0.40, 0.75, 0.40};
  Set<double> b = {0.16, 0.25, 0.45, 0.75, 0.45};
  // print(a);
  // print(b);
  // Set<double> res = unionSet(a, b);
  Set<double> unionSet = a.union(b);
  print("A, B 합집합: $unionSet");
  // Set<double> kyoSet = findSameSetElement(a, b);
  Set<double> kyoSet = a.intersection(b);
  print("A, B 교집합: $kyoSet");
  Set<double> chaSet = a.difference(b);
  print("A-B 차집합: $chaSet");
}
